// hooks/useRealtimeTracking.ts
'use client';

import { useState, useEffect, useCallback } from 'react';
import { gpsService, RealtimeTruckPosition } from '@/services/gps.service';
import toast from 'react-hot-toast';

export function useRealtimeTracking(interval: number = 5000) {
  const [positions, setPositions] = useState<RealtimeTruckPosition[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const fetchPositions = useCallback(async () => {
    try {
      const data = await gpsService.getCurrentPositions();
      setPositions(data);
      setLastUpdate(new Date());
      setError(null);
    } catch (err) {
      setError('Erreur lors du chargement des positions');
      toast.error('Erreur de mise à jour des positions');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPositions();

    const intervalId = setInterval(fetchPositions, interval);

    return () => clearInterval(intervalId);
  }, [fetchPositions, interval]);

  return { positions, loading, error, lastUpdate, refresh: fetchPositions };
}