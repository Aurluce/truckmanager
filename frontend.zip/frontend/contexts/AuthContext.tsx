'use client';

import React, { createContext, useState, useEffect } from 'react';
import { User, LoginCredentials, RegisterCredentials, AuthResponse } from '@/types';
import api from '@/services/api';
import toast from 'react-hot-toast';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (data: RegisterCredentials) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

const TOKEN_KEY = 'truckmanager_token';
const USER_KEY = 'truckmanager_user';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedToken = localStorage.getItem(TOKEN_KEY);
    const storedUser = localStorage.getItem(USER_KEY);
    
    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
      api.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
    }
    setIsLoading(false);
  }, []);

  const login = async (credentials: LoginCredentials) => {
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
      delete api.defaults.headers.common['Authorization'];
      document.cookie = 'truckmanager_token=; Max-Age=0; path=/; SameSite=Lax';
      document.cookie = 'truckmanager_refresh=; Max-Age=0; path=/; SameSite=Lax';

      const response = await api.post<AuthResponse>('/auth/login/', credentials);
      const access = response.data.access ?? response.data.tokens?.access;
      const refresh = response.data.refresh ?? response.data.tokens?.refresh;
      const user = response.data.user;

      if (!access || !user) {
        throw new Error('Réponse de connexion invalide');
      }

      localStorage.setItem(TOKEN_KEY, access);
      if (refresh) {
        localStorage.setItem('truckmanager_refresh', refresh);
        document.cookie = `truckmanager_refresh=${refresh}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
      }
      localStorage.setItem(USER_KEY, JSON.stringify(user));
      document.cookie = `truckmanager_token=${access}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
      api.defaults.headers.common['Authorization'] = `Bearer ${access}`;

      setToken(access);
      setUser(user);

      toast.success('Connexion réussie !');
    } catch (error: any) {
      const message = error.response?.data?.non_field_errors?.[0] 
                    || error.response?.data?.error 
                    || 'Erreur de connexion';
      toast.error(message);
      throw error;
    }
  };

  const register = async (data: RegisterCredentials) => {
    try {
      await api.post('/auth/register/', data);
      toast.success('Inscription réussie ! Vous pouvez vous connecter.');
    } catch (error: any) {
      const errors = error.response?.data;
      if (errors) {
        // Check for non_field_errors first (DRF format)
        if (errors.non_field_errors && Array.isArray(errors.non_field_errors)) {
          toast.error(errors.non_field_errors[0]);
        } else {
          // Get the first error from any field
          const firstError = Object.values(errors)[0];
          toast.error(typeof firstError === 'string' ? firstError : 'Erreur d\'inscription');
        }
      } else {
        toast.error('Erreur d\'inscription');
      }
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem('truckmanager_refresh');
    delete api.defaults.headers.common['Authorization'];
    document.cookie = 'truckmanager_token=; Max-Age=0; path=/; SameSite=Lax';
    document.cookie = 'truckmanager_refresh=; Max-Age=0; path=/; SameSite=Lax';
    setToken(null);
    setUser(null);
    toast.success('Déconnexion réussie');
  };

  const isAuthenticated = !!token && !!user;
  const isAdmin = user?.is_superuser || user?.role === 'ADMIN' || false;

  return (
    <AuthContext.Provider value={{
      user,
      token,
      isLoading,
      login,
      register,
      logout,
      isAuthenticated,
      isAdmin,
    }}>
      {children}
    </AuthContext.Provider>
  );
}
