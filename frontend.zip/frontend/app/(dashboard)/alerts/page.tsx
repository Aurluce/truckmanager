// app/(dashboard)/alerts/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import api from '@/services/api';
import { Alert, PaginatedResponse } from '@/types';
import {
  MagnifyingGlassIcon,
  CheckCircleIcon,
  XCircleIcon,
  EyeIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function AlertsPage() {
  const { isAuthenticated } = useAuth();
  const router = useRouter();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('');

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    fetchAlerts();
  }, [isAuthenticated, router, filter]);

  const fetchAlerts = async () => {
    try {
      const params: any = {};
      if (filter) params.status = filter;
      
      const response = await api.get<PaginatedResponse<Alert>>('/alerts/', { params });
      setAlerts(response.data.results);
    } catch (error) {
      toast.error('Erreur lors du chargement des alertes');
    } finally {
      setLoading(false);
    }
  };

  const handleResolve = async (id: number) => {
    try {
      await api.post(`/alerts/${id}/resolve/`);
      toast.success('Alerte résolue');
      fetchAlerts();
    } catch (error) {
      toast.error('Erreur lors de la résolution');
    }
  };

  const handleIgnore = async (id: number) => {
    try {
      await api.post(`/alerts/${id}/ignore/`);
      toast.success('Alerte ignorée');
      fetchAlerts();
    } catch (error) {
      toast.error('Erreur lors de l\'ignorance');
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="spinner w-16 h-16 border-4 border-blue-200 border-t-blue-600 mx-auto" />
            <p className="mt-4 text-gray-500">Chargement des alertes...</p>
          </div>
        </div>
      </Layout>
    );
  }

  const getStatusColor = (status: string) => {
    const colors = {
      'PENDING': 'badge-warning',
      'RESOLVED': 'badge-success',
      'IGNORED': 'badge-gray',
      'IN_PROGRESS': 'badge-info',
    };
    return colors[status as keyof typeof colors] || 'badge-gray';
  };

  const getTypeIcon = (type: string) => {
    const icons: Record<string, string> = {
      'OVERLOAD': '⚠️',
      'FUEL_THEFT': '⛽',
      'ABNORMAL_STOP': '🛑',
      'LOW_FUEL': '🔋',
      'SPEEDING': '🏎️',
      'MAINTENANCE': '🔧',
    };
    return icons[type] || '📢';
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Alertes</h1>
            <p className="text-gray-500 text-sm">Surveillance des alertes en temps réel</p>
          </div>
        </div>

        {/* Filters */}
        <Card className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="flex gap-2 flex-wrap">
                <Button
                  variant={filter === '' ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setFilter('')}
                >
                  Toutes
                </Button>
                <Button
                  variant={filter === 'PENDING' ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setFilter('PENDING')}
                >
                  En attente
                </Button>
                <Button
                  variant={filter === 'IN_PROGRESS' ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setFilter('IN_PROGRESS')}
                >
                  En cours
                </Button>
                <Button
                  variant={filter === 'RESOLVED' ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setFilter('RESOLVED')}
                >
                  Résolues
                </Button>
                <Button
                  variant={filter === 'IGNORED' ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => setFilter('IGNORED')}
                >
                  Ignorées
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* Alerts List */}
        <div className="space-y-3">
          {alerts.map((alert, index) => (
            <div
              key={alert.id}
              className={`bg-white rounded-xl shadow-card p-5 animate-fade-in delay-${(index % 4 + 1) * 100} hover:shadow-card-hover transition-all duration-300 ${
                alert.status === 'PENDING' ? 'border-l-4 border-yellow-500' : ''
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                <div className="flex gap-3">
                  <div className="text-2xl">{getTypeIcon(alert.alert_type)}</div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-gray-900">
                        {alert.alert_type_display}
                      </span>
                      <span className={`badge ${getStatusColor(alert.status)}`}>
                        {alert.status_display}
                      </span>
                      <span className="text-sm text-gray-500">
                        Camion {alert.truck_id}
                      </span>
                    </div>
                    <p className="text-gray-700 mt-1">{alert.message}</p>
                    <div className="flex gap-4 mt-2 text-sm text-gray-500">
                      <span>Seuil: {alert.threshold_value}</span>
                      <span>Valeur: {alert.actual_value}</span>
                      <span>
                        {new Date(alert.triggered_at).toLocaleDateString('fr-FR', {
                          day: '2-digit',
                          month: '2-digit',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  {alert.status === 'PENDING' && (
                    <>
                      <Button
                        variant="success"
                        size="sm"
                        icon={<CheckCircleIcon className="w-4 h-4" />}
                        onClick={() => handleResolve(alert.id)}
                      >
                        Résoudre
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<XCircleIcon className="w-4 h-4" />}
                        onClick={() => handleIgnore(alert.id)}
                        className="text-gray-500"
                      >
                        Ignorer
                      </Button>
                    </>
                  )}
                  {alert.status === 'RESOLVED' && (
                    <span className="text-sm text-green-600 font-medium flex items-center gap-1">
                      <CheckCircleIcon className="w-4 h-4" />
                      Résolu
                    </span>
                  )}
                  {alert.status === 'IGNORED' && (
                    <span className="text-sm text-gray-500 font-medium">Ignoré</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {alerts.length === 0 && (
          <div className="text-center py-12 bg-white rounded-2xl shadow-card">
            <div className="text-4xl mb-4">✅</div>
            <h3 className="text-lg font-semibold text-gray-900">Aucune alerte</h3>
            <p className="text-gray-500 mt-1">Toutes les alertes sont résolues ou ignorées</p>
          </div>
        )}
      </div>
    </Layout>
  );
}