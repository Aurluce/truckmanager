// app/(dashboard)/dashboard/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import api from '@/services/api';
import { DashboardSummary } from '@/types';
import {
  TruckIcon,
  ChartBarIcon,
  BellIcon,
  CurrencyDollarIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  MapPinIcon,
  ClockIcon,
  FireIcon,
  DocumentTextIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function DashboardPage() {
  const { isAuthenticated } = useAuth();
  const router = useRouter();
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    fetchDashboardSummary();
  }, [isAuthenticated, router]);

  const fetchDashboardSummary = async () => {
    try {
      const response = await api.get('/dashboard/summary/');
      setSummary(response.data);
    } catch (error) {
      toast.error('Erreur lors du chargement du dashboard');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardSummary();
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="spinner w-16 h-16 border-4 border-blue-200 border-t-blue-600 mx-auto" />
            <p className="mt-4 text-gray-500">Chargement du dashboard...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!summary) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <p className="text-gray-500 text-lg">Aucune donnée disponible</p>
            <Button onClick={handleRefresh} className="mt-4">
              Rafraîchir
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  const stats = [
    {
      title: 'Camions',
      value: summary.trucks.total_trucks,
      subtitle: `${summary.trucks.in_trip} en trajet, ${summary.trucks.idle} à l'arrêt`,
      icon: TruckIcon,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      trend: '+12%',
      trendUp: true,
    },
    {
      title: 'Trajets',
      value: summary.trips.total_trips,
      subtitle: `${summary.trips.completed} terminés, ${summary.trips.in_progress} en cours`,
      icon: ChartBarIcon,
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600',
      trend: '+8%',
      trendUp: true,
    },
    {
      title: 'Alertes',
      value: summary.alerts.total_alerts,
      subtitle: `${summary.alerts.pending} en attente, ${summary.alerts.resolved} résolues`,
      icon: BellIcon,
      color: 'from-red-500 to-red-600',
      bgColor: 'bg-red-50',
      iconColor: 'text-red-600',
      trend: '-3%',
      trendUp: false,
    },
    {
      title: 'Recette',
      value: new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XAF' }).format(summary.financial.total_revenue_fcfa),
      subtitle: `Bénéfice: ${new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XAF' }).format(summary.financial.profit_fcfa)}`,
      icon: CurrencyDollarIcon,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      iconColor: 'text-purple-600',
      trend: '+15%',
      trendUp: true,
    },
  ];

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 animate-fade-in">
              Tableau de bord
            </h1>
            <p className="text-gray-500 text-sm animate-fade-in delay-100">
              Vue d'ensemble de votre flotte en temps réel
            </p>
          </div>
          <Button
            onClick={handleRefresh}
            isLoading={refreshing}
            variant="gradient"
            icon={<ArrowTrendingUpIcon className="w-4 h-4" />}
          >
            Rafraîchir
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`bg-white rounded-2xl shadow-card p-6 animate-fade-in delay-${(index + 1) * 100}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1 truncate">
                    {stat.value}
                  </p>
                  <p className="text-xs text-gray-400 mt-1 truncate">{stat.subtitle}</p>
                </div>
                <div className={`p-3 rounded-xl ${stat.bgColor}`}>
                  <stat.icon className={`w-6 h-6 ${stat.iconColor}`} />
                </div>
              </div>
              {stat.trend && (
                <div className="mt-3 flex items-center gap-1">
                  <span className={`text-xs font-semibold ${stat.trendUp ? 'text-green-600' : 'text-red-600'}`}>
                    {stat.trend}
                  </span>
                  <span className="text-xs text-gray-400">vs mois dernier</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Performance Trajets */}
          <Card title="Performance des trajets" className="animate-fade-in delay-200">
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                <span className="text-gray-600">Distance totale</span>
                <span className="font-semibold text-gray-900">
                  {summary.trips.total_distance_km.toFixed(1)} km
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                <span className="text-gray-600">Consommation totale</span>
                <span className="font-semibold text-gray-900">
                  {summary.trips.total_fuel_l.toFixed(1)} L
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                <span className="text-gray-600">Consommation moyenne</span>
                <span className="font-semibold text-gray-900">
                  {summary.trips.avg_consumption_l_100km.toFixed(1)} L/100km
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                <span className="text-gray-600">Poids moyen</span>
                <span className="font-semibold text-gray-900">
                  {(summary.trips.avg_weight_kg / 1000).toFixed(1)} t
                </span>
              </div>
            </div>
          </Card>

          {/* Alertes par type */}
          <Card title="Alertes par type" className="animate-fade-in delay-300">
            <div className="space-y-3">
              {summary.alerts.by_type.length > 0 ? (
                summary.alerts.by_type.map((alert, index) => (
                  <div
                    key={index}
                    className="flex justify-between items-center p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                  >
                    <span className="text-gray-700">{alert.alert_type}</span>
                    <span className={`badge ${alert.count > 0 ? 'badge-danger' : 'badge-gray'}`}>
                      {alert.count}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <div className="text-4xl mb-2">🎉</div>
                  <p className="text-gray-500">Aucune alerte enregistrée</p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="bg-gradient-accent rounded-2xl p-6 text-white animate-fade-in delay-400">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold">Actions rapides</h3>
              <p className="text-white/70 text-sm">Gérez votre flotte en un clic</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button variant="primary" className="bg-white/20 hover:bg-white/30 text-white border border-white/30">
                <TruckIcon className="w-4 h-4" />
                Ajouter un camion
              </Button>
              <Button variant="primary" className="bg-white/20 hover:bg-white/30 text-white border border-white/30">
                <DocumentTextIcon className="w-4 h-4" />
                Générer un rapport
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}