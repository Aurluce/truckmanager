// app/(dashboard)/map/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Map } from '@/components/map/Map';
import { useAuth } from '@/hooks/useAuth';
import { useRealtimeTracking } from '@/hooks/useRealtimeTracking';
import { gpsService } from '@/services/gps.service';
import { 
  ArrowPathIcon,
  TruckIcon,
  SignalIcon,
  ClockIcon,
  MapPinIcon,
  WifiIcon
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import router from 'next/dist/shared/lib/router/router';

export default function MapPage() {
  const { isAuthenticated } = useAuth();
  const { positions, loading, lastUpdate, refresh } = useRealtimeTracking(10000);
  const [selectedTruck, setSelectedTruck] = useState<string | null>(null);
  const [trailPositions, setTrailPositions] = useState<any[]>([]);
  const [showTrail, setShowTrail] = useState(false);
  const [center, setCenter] = useState({ lat: 4.0511, lng: 9.7679 });

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
  }, [isAuthenticated]);

  // Trouver la position centrale
  useEffect(() => {
    if (positions.length > 0 && positions[0].position) {
      setCenter({
        lat: positions[0].position.lat,
        lng: positions[0].position.lng,
      });
    }
  }, [positions]);

  const handleMarkerClick = async (truckId: string) => {
    setSelectedTruck(truckId);
    setShowTrail(true);
    
    try {
      // Récupérer le trajet en cours
      const response = await gpsService.getRealtimeData(truckId);
      if (response.trip_id) {
        const trace = await gpsService.getTripTrace(response.trip_id);
        setTrailPositions(trace.map(p => ({
          lat: p.latitude,
          lng: p.longitude,
        })));
      }
      toast.success(`Suivi de ${truckId} activé`);
    } catch (error) {
      toast.error('Erreur lors du chargement du trajet');
    }
  };

  const stats = {
    total: positions.length,
    inTrip: positions.filter(p => p.status === 'IN_TRIP').length,
    idle: positions.filter(p => p.status === 'IDLE').length,
    offline: positions.filter(p => p.status === 'OFFLINE').length,
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Suivi GPS en temps réel</h1>
            <p className="text-gray-500 text-sm">
              Visualisez la position de vos camions en temps réel
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              icon={<ArrowPathIcon className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />}
              onClick={refresh}
            >
              Rafraîchir
            </Button>
            <Button
              variant={showTrail ? 'primary' : 'secondary'}
              size="sm"
              onClick={() => setShowTrail(!showTrail)}
            >
              {showTrail ? 'Masquer traces' : 'Afficher traces'}
            </Button>
          </div>
        </div>

        {/* Statistiques */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Card className="p-4 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-50 rounded-xl">
                <TruckIcon className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Total camions</p>
                <p className="text-xl font-bold text-gray-900">{stats.total}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 animate-fade-in delay-100">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-50 rounded-xl">
                <SignalIcon className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">En trajet</p>
                <p className="text-xl font-bold text-green-600">{stats.inTrip}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 animate-fade-in delay-200">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-50 rounded-xl">
                <ClockIcon className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">À l'arrêt</p>
                <p className="text-xl font-bold text-yellow-600">{stats.idle}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4 animate-fade-in delay-300">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-50 rounded-xl">
                <WifiIcon className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Hors ligne</p>
                <p className="text-xl font-bold text-red-600">{stats.offline}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Carte */}
        <Card className="p-0 overflow-hidden">
          <Map
            positions={positions}
            center={center}
            zoom={12}
            showTrail={showTrail}
            trailPositions={trailPositions}
            onMarkerClick={handleMarkerClick}
          />
        </Card>

        {/* Dernière mise à jour */}
        <div className="text-center text-sm text-gray-400">
          Dernière mise à jour: {lastUpdate ? new Date(lastUpdate).toLocaleString('fr-FR') : '...'}
          <span className="mx-2">•</span>
          Mise à jour automatique toutes les 10 secondes
        </div>

        {/* Liste des camions */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Liste des camions
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {positions.map((truck) => (
              <div
                key={truck.truck_id}
                className={`p-3 rounded-xl border transition-all cursor-pointer hover:shadow-card ${
                  selectedTruck === truck.truck_id 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => handleMarkerClick(truck.truck_id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${
                      truck.status === 'IN_TRIP' ? 'bg-green-500' :
                      truck.status === 'IDLE' ? 'bg-yellow-500' :
                      'bg-red-500'
                    }`} />
                    <span className="font-medium text-gray-900">
                      {truck.license_plate}
                    </span>
                  </div>
                  <Badge
                    variant={
                      truck.status === 'IN_TRIP' ? 'success' :
                      truck.status === 'IDLE' ? 'warning' :
                      'danger'
                    }
                    size="sm"
                  >
                    {truck.status === 'IN_TRIP' ? 'En trajet' :
                     truck.status === 'IDLE' ? 'À l\'arrêt' :
                     'Hors ligne'}
                  </Badge>
                </div>
                <div className="mt-2 text-sm text-gray-500 flex items-center gap-2">
                  <MapPinIcon className="w-4 h-4" />
                  {truck.position ? (
                    <>
                      {truck.position.lat.toFixed(4)}, {truck.position.lng.toFixed(4)}
                      <span className="mx-1">•</span>
                      {truck.speed} km/h
                    </>
                  ) : (
                    'Position inconnue'
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </Layout>
  );
}