// app/(dashboard)/trucks/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import api from '@/services/api';
import { Truck, PaginatedResponse } from '@/types';
import { 
  PlusIcon, 
  MagnifyingGlassIcon,
  FunnelIcon,
  PencilIcon,
  TrashIcon,
  EyeIcon
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function TrucksPage() {
  const { isAuthenticated } = useAuth();
  const router = useRouter();
  const [trucks, setTrucks] = useState<Truck[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterActive, setFilterActive] = useState<boolean | null>(null);

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
      return;
    }
    fetchTrucks();
  }, [isAuthenticated, router, search, filterActive]);

  const fetchTrucks = async () => {
    try {
      const params: any = {};
      if (search) params.search = search;
      if (filterActive !== null) params.is_active = filterActive;
      
      const response = await api.get<PaginatedResponse<Truck>>('/trucks/', { params });
      setTrucks(response.data.results);
    } catch (error) {
      toast.error('Erreur lors du chargement des camions');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Voulez-vous vraiment supprimer ce camion ?')) return;
    try {
      await api.delete(`/trucks/${id}/`);
      toast.success('Camion supprimé avec succès');
      fetchTrucks();
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="spinner w-16 h-16 border-4 border-blue-200 border-t-blue-600 mx-auto" />
            <p className="mt-4 text-gray-500">Chargement des camions...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Camions</h1>
            <p className="text-gray-500 text-sm">Gestion de votre flotte de camions</p>
          </div>
          <Button
            variant="gradient"
            icon={<PlusIcon className="w-4 h-4" />}
            onClick={() => router.push('/dashboard/trucks/new')}
          >
            Nouveau camion
          </Button>
        </div>

        {/* Filters */}
        <Card className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Rechercher un camion..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterActive === null ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setFilterActive(null)}
              >
                Tous
              </Button>
              <Button
                variant={filterActive === true ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setFilterActive(true)}
              >
                Actifs
              </Button>
              <Button
                variant={filterActive === false ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setFilterActive(false)}
              >
                Inactifs
              </Button>
            </div>
          </div>
        </Card>

        {/* Trucks Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {trucks.map((truck, index) => (
            <div
              key={truck.id}
              className={`bg-white rounded-2xl shadow-card hover:shadow-card-hover transition-all duration-300 p-6 animate-fade-in delay-${(index % 4 + 1) * 100}`}
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {truck.truck_id}
                  </h3>
                  <p className="text-sm text-gray-500">{truck.license_plate}</p>
                </div>
                <span className={`badge ${truck.is_active ? 'badge-success' : 'badge-gray'}`}>
                  {truck.is_active ? 'Actif' : 'Inactif'}
                </span>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Marque</span>
                  <span className="font-medium text-gray-900">{truck.brand}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Modèle</span>
                  <span className="font-medium text-gray-900">{truck.model}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Année</span>
                  <span className="font-medium text-gray-900">{truck.year}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Capacité</span>
                  <span className="font-medium text-gray-900">
                    {(truck.max_capacity_kg / 1000).toFixed(1)} t
                  </span>
                </div>
              </div>

              <div className="flex gap-2 mt-4 pt-4 border-t border-gray-100">
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<EyeIcon className="w-4 h-4" />}
                  onClick={() => router.push(`/dashboard/trucks/${truck.id}`)}
                  className="flex-1"
                >
                  Voir
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<PencilIcon className="w-4 h-4" />}
                  onClick={() => router.push(`/dashboard/trucks/${truck.id}/edit`)}
                  className="flex-1"
                >
                  Modifier
                </Button>
                <Button
                          variant="ghost"
                          size="sm"
                          icon={<TrashIcon className="w-4 h-4" />}
                          onClick={() => handleDelete(truck.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50" children={undefined}                />
              </div>
            </div>
          ))}
        </div>

        {trucks.length === 0 && (
          <div className="text-center py-12 bg-white rounded-2xl shadow-card">
            <div className="text-4xl mb-4">🚛</div>
            <h3 className="text-lg font-semibold text-gray-900">Aucun camion</h3>
            <p className="text-gray-500 mt-1">Commencez par ajouter votre premier camion</p>
            <Button
              variant="gradient"
              className="mt-4"
              onClick={() => router.push('/dashboard/trucks/new')}
            >
              Ajouter un camion
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}