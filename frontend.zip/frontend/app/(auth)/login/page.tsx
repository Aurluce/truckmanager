// app/(auth)/login/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { useAuth } from '@/hooks/useAuth';
import { LoginCredentials } from '@/types';
import { 
  TruckIcon, 
  EnvelopeIcon,
  LockClosedIcon,
  EyeIcon,
  EyeSlashIcon,
  ArrowRightIcon,
  CheckCircleIcon
} from '@heroicons/react/24/outline';

export default function LoginPage() {
  const router = useRouter();
  const { login, isLoading } = useAuth();
  const [credentials, setCredentials] = useState<LoginCredentials>({
    username: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Animation des particules
    const createParticles = () => {
      const container = document.querySelector('.particles-container');
      if (!container) return;
      
      for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.width = `${Math.random() * 4 + 2}px`;
        particle.style.height = particle.style.width;
        particle.style.animationDuration = `${Math.random() * 20 + 10}s`;
        particle.style.animationDelay = `${Math.random() * 10}s`;
        particle.style.opacity = Math.random() * 0.5 + 0.1;
        container.appendChild(particle);
      }
    };
    createParticles();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await login(credentials);
      router.push('/dashboard');
    } catch (err: any) {
      const errorMessage = err.response?.data?.non_field_errors?.[0] 
                        || err.response?.data?.error 
                        || 'Identifiants incorrects';
      setError(errorMessage);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-primary">
      {/* Particules en arrière-plan */}
      <div className="particles-container absolute inset-0 pointer-events-none" />
      
      {/* Logo PNG en arrière-plan */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10 select-none">
        <div className="relative w-[600px] h-[600px] animate-float">
          <Image
            src="/images/logo.png"
            alt="TruckManager Logo"
            fill
            className="object-contain"
            priority
          />
        </div>
      </div>

      {/* Pattern overlay */}
      <div className="absolute inset-0 bg-grid opacity-10" />

      <div className="relative z-10 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md">
          {/* Logo et marque - Version miniature */}
          <div className="text-center mb-8 animate-fade-in">
            <div className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-sm px-6 py-3 rounded-2xl border border-white/10">
              <div className="relative w-10 h-10">
                <Image
                  src="/images/logo.png"
                  alt="TruckManager Logo"
                  fill
                  className="object-contain"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">TruckManager</h1>
                <p className="text-white/50 text-xs">Gestion de flotte intelligente</p>
              </div>
            </div>
          </div>

          {/* Formulaire Glassmorphique */}
          <div className="glass rounded-3xl p-8 shadow-2xl animate-fade-in delay-100 border border-white/10">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white">Bienvenue</h2>
              <p className="text-white/60 text-sm mt-1">
                Connectez-vous pour accéder à votre espace
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-200 text-sm flex items-center gap-2 animate-fade-in">
                <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Champ Nom d'utilisateur */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                  <EnvelopeIcon className="w-4 h-4" />
                  Nom d'utilisateur ou email
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    placeholder="Entrez votre nom d'utilisateur ou email"
                    value={credentials.username}
                    onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-white/20">
                    <CheckCircleIcon className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Champ Mot de passe */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                    <LockClosedIcon className="w-4 h-4" />
                    Mot de passe
                  </label>
                  <Link href="/forgot-password" className="text-xs text-white/40 hover:text-white/70 transition-colors">
                    Mot de passe oublié ?
                  </Link>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 pr-12"
                    placeholder="Entrez votre mot de passe"
                    value={credentials.password}
                    onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors"
                  >
                    {showPassword ? (
                      <EyeSlashIcon className="w-5 h-5" />
                    ) : (
                      <EyeIcon className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Options */}
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-sm text-white/60 cursor-pointer group">
                  <div className="relative">
                    <input
                      type="checkbox"
                      className="sr-only"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                    />
                    <div className={`w-5 h-5 rounded-md border-2 transition-all duration-200 flex items-center justify-center ${
                      rememberMe 
                        ? 'bg-blue-500 border-blue-500' 
                        : 'border-white/30 group-hover:border-white/50'
                    }`}>
                      {rememberMe && (
                        <CheckCircleIcon className="w-3.5 h-3.5 text-white" />
                      )}
                    </div>
                  </div>
                  Se souvenir de moi
                </label>
              </div>

              {/* Bouton de connexion */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-gradient-accent text-white font-semibold rounded-xl shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all duration-300 flex items-center justify-center gap-2 group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <span className="spinner w-5 h-5 border-2 border-white/30 border-t-white" />
                    Connexion en cours...
                  </>
                ) : (
                  <>
                    Se connecter
                    <ArrowRightIcon className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>

              {/* Lien d'inscription */}
              <div className="text-center pt-4 border-t border-white/5">
                <p className="text-white/50 text-sm">
                  Pas encore de compte ?{' '}
                  <Link href="/register" className="text-white hover:text-blue-400 transition-colors font-medium">
                    S'inscrire
                  </Link>
                </p>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div className="text-center mt-6 text-white/30 text-xs">
            © 2024 TruckManager. Tous droits réservés.
          </div>
        </div>
      </div>

      {/* Styles personnalisés pour la page */}
      <style jsx>{`
        .glass {
          background: rgba(255, 255, 255, 0.08);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .bg-grid {
          background-image: 
            linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px);
          background-size: 60px 60px;
        }
        .particle {
          position: absolute;
          background: rgba(255, 255, 255, 0.5);
          border-radius: 50%;
          animation: floatParticle linear infinite;
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        @keyframes floatParticle {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(-100vh) rotate(720deg); opacity: 0; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px) scale(1); }
          50% { transform: translateY(-20px) scale(1.05); }
        }
      `}</style>
    </div>
  );
}