// app/(auth)/register/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { useAuth } from '@/hooks/useAuth';
import { RegisterCredentials } from '@/types';
import { 
  TruckIcon,
  UserIcon,
  EnvelopeIcon,
  LockClosedIcon,
  EyeIcon,
  EyeSlashIcon,
  ArrowRightIcon,
  CheckCircleIcon,
  UserPlusIcon
} from '@heroicons/react/24/outline';

export default function RegisterPage() {
  const router = useRouter();
  const { register, isLoading } = useAuth();
  const [formData, setFormData] = useState<RegisterCredentials>({
    username: '',
    email: '',
    password: '',
    confirm_password: '',
    first_name: '',
    last_name: '',
    role: 'OWNER',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [passwordStrength, setPasswordStrength] = useState(0);

  useEffect(() => {
    // Animation des particules
    const createParticles = () => {
      const container = document.querySelector('.particles-container');
      if (!container) return;
      
      for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.width = `${Math.random() * 4 + 2}px`;
        particle.style.height = particle.style.width;
        particle.style.animationDuration = `${Math.random() * 20 + 10}s`;
        particle.style.animationDelay = `${Math.random() * 10}s`;
        particle.style.opacity = Math.random() * 0.5 + 0.1;
        container.appendChild(particle);
      }
    };
    createParticles();
  }, []);

  // Vérification de la force du mot de passe
  useEffect(() => {
    const password = formData.password;
    let strength = 0;
    if (password.length >= 6) strength += 1;
    if (password.length >= 10) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    setPasswordStrength(Math.min(strength, 4));
  }, [formData.password]);

  const getPasswordStrengthColor = () => {
    const colors = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-green-500'];
    return colors[passwordStrength - 1] || 'bg-gray-500';
  };

  const getPasswordStrengthText = () => {
    const texts = ['Très faible', 'Faible', 'Moyen', 'Fort'];
    return texts[passwordStrength - 1] || '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (formData.password !== formData.confirm_password) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }

    if (passwordStrength < 2) {
      setError('Le mot de passe est trop faible');
      return;
    }

    try {
      await register(formData);
      router.push('/login');
    } catch (err: any) {
      const errors = err.response?.data;
      if (errors) {
        // Check for non_field_errors first (DRF format)
        if (errors.non_field_errors && Array.isArray(errors.non_field_errors)) {
          setError(errors.non_field_errors[0]);
        } else {
          // Get the first error from any field
          const firstError = Object.values(errors)[0];
          setError(typeof firstError === 'string' ? firstError : 'Erreur d\'inscription');
        }
      } else {
        setError('Erreur d\'inscription');
      }
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-primary">
      {/* Particules en arrière-plan */}
      <div className="particles-container absolute inset-0 pointer-events-none" />
      
      {/* Logo PNG en arrière-plan */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10 select-none">
        <div className="relative w-[600px] h-[600px] animate-float">
          <Image
            src="/images/logo.png"
            alt="TruckManager Logo"
            fill
            className="object-contain"
            priority
          />
        </div>
      </div>

      {/* Pattern overlay */}
      <div className="absolute inset-0 bg-grid opacity-10" />

      <div className="relative z-10 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md">
          {/* Logo et marque - Version miniature */}
          <div className="text-center mb-8 animate-fade-in">
            <div className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-sm px-6 py-3 rounded-2xl border border-white/10">
              <div className="relative w-10 h-10">
                <Image
                  src="/images/logo.png"
                  alt="TruckManager Logo"
                  fill
                  className="object-contain"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">TruckManager</h1>
                <p className="text-white/50 text-xs">Gestion de flotte intelligente</p>
              </div>
            </div>
          </div>

          {/* Formulaire Glassmorphique */}
          <div className="glass rounded-3xl p-8 shadow-2xl animate-fade-in delay-100 border border-white/10">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white">Créer un compte</h2>
              <p className="text-white/60 text-sm mt-1">
                Rejoignez TruckManager dès maintenant
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-200 text-sm flex items-center gap-2 animate-fade-in">
                <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Nom et Prénom */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                    <UserIcon className="w-4 h-4" />
                    Prénom
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-sm"
                    placeholder="Prénom"
                    value={formData.first_name}
                    onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                    <UserIcon className="w-4 h-4" />
                    Nom
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-sm"
                    placeholder="Nom"
                    value={formData.last_name}
                    onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                  />
                </div>
              </div>

              {/* Nom d'utilisateur */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                  <UserIcon className="w-4 h-4" />
                  Nom d'utilisateur
                </label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-sm"
                  placeholder="Choisissez un nom d'utilisateur"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                />
              </div>

              {/* Rôle */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                  <TruckIcon className="w-4 h-4" />
                  Rôle
                </label>
                <select
                  value={formData.role || 'OWNER'}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value as 'ADMIN' | 'OWNER' })}
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-sm"
                >
                  <option value="OWNER" className="text-gray-900">Propriétaire</option>
                  <option value="ADMIN" className="text-gray-900">Administrateur</option>
                </select>
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                  <EnvelopeIcon className="w-4 h-4" />
                  Email
                </label>
                <input
                  type="email"
                  required
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-sm"
                  placeholder="votre@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>

              {/* Mot de passe */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                  <LockClosedIcon className="w-4 h-4" />
                  Mot de passe
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-sm pr-12"
                    placeholder="Minimum 6 caractères"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors"
                  >
                    {showPassword ? (
                      <EyeSlashIcon className="w-5 h-5" />
                    ) : (
                      <EyeIcon className="w-5 h-5" />
                    )}
                  </button>
                </div>
                
                {/* Indicateur de force du mot de passe */}
                {formData.password && (
                  <div className="space-y-1">
                    <div className="flex gap-1">
                      {[...Array(4)].map((_, i) => (
                        <div
                          key={i}
                          className={`h-1 flex-1 rounded-full transition-all duration-300 ${
                            i < passwordStrength ? getPasswordStrengthColor() : 'bg-white/10'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-white/50">
                      Force : <span className="text-white/80">{getPasswordStrengthText()}</span>
                    </p>
                  </div>
                )}
              </div>

              {/* Confirmation mot de passe */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-white/80 flex items-center gap-2">
                  <LockClosedIcon className="w-4 h-4" />
                  Confirmer le mot de passe
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    required
                    className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 text-sm pr-12"
                    placeholder="Confirmez votre mot de passe"
                    value={formData.confirm_password}
                    onChange={(e) => setFormData({ ...formData, confirm_password: e.target.value })}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors"
                  >
                    {showConfirmPassword ? (
                      <EyeSlashIcon className="w-5 h-5" />
                    ) : (
                      <EyeIcon className="w-5 h-5" />
                    )}
                  </button>
                </div>
                {formData.confirm_password && formData.password !== formData.confirm_password && (
                  <p className="text-xs text-red-400">
                    Les mots de passe ne correspondent pas
                  </p>
                )}
              </div>

              {/* Bouton d'inscription */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-gradient-accent text-white font-semibold rounded-xl shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all duration-300 flex items-center justify-center gap-2 group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <span className="spinner w-5 h-5 border-2 border-white/30 border-t-white" />
                    Création du compte...
                  </>
                ) : (
                  <>
                    <UserPlusIcon className="w-4 h-4" />
                    Créer le compte
                    <ArrowRightIcon className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>

              {/* Lien de connexion */}
              <div className="text-center pt-4 border-t border-white/5">
                <p className="text-white/50 text-sm">
                  Déjà un compte ?{' '}
                  <Link href="/login" className="text-white hover:text-blue-400 transition-colors font-medium">
                    Se connecter
                  </Link>
                </p>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div className="text-center mt-6 text-white/30 text-xs">
            © 2024 TruckManager. Tous droits réservés.
          </div>
        </div>
      </div>

      {/* Styles personnalisés pour la page */}
      <style jsx>{`
        .glass {
          background: rgba(255, 255, 255, 0.08);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .bg-grid {
          background-image: 
            linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px);
          background-size: 60px 60px;
        }
        .particle {
          position: absolute;
          background: rgba(255, 255, 255, 0.5);
          border-radius: 50%;
          animation: floatParticle linear infinite;
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        @keyframes floatParticle {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { transform: translateY(-100vh) rotate(720deg); opacity: 0; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px) scale(1); }
          50% { transform: translateY(-20px) scale(1.05); }
        }
      `}</style>
    </div>
  );
}