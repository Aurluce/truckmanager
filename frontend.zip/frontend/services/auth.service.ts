import api from './api';
import { 
  LoginCredentials, 
  RegisterCredentials, 
  AuthResponse, 
  User,
  ChangePasswordData 
} from '@/types';

export const authService = {
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const response = await api.post<AuthResponse>('/auth/login/', credentials);
    return response.data;
  },

  async register(data: RegisterCredentials): Promise<{ message: string }> {
    const response = await api.post('/auth/register/', data);
    return response.data;
  },

  async logout(refreshToken: string): Promise<void> {
    await api.post('/auth/logout/', { refresh: refreshToken });
  },

  async getProfile(): Promise<User> {
    const response = await api.get<User>('/auth/profile/');
    return response.data;
  },

  async updateProfile(data: Partial<User>): Promise<User> {
    const response = await api.put<User>('/auth/profile/', data);
    return response.data;
  },

  async changePassword(data: ChangePasswordData): Promise<{ message: string }> {
    const response = await api.post('/auth/change-password/', data);
    return response.data;
  },

  async refreshToken(refresh: string): Promise<{ access: string }> {
    const response = await api.post('/auth/token/refresh/', { refresh });
    return response.data;
  },
};
