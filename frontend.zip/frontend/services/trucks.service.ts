import api from './api';
import { Truck, TruckStats, PaginatedResponse } from '@/types';

export const trucksService = {
  async getAll(params?: { page?: number; search?: string; is_active?: boolean }): Promise<PaginatedResponse<Truck>> {
    const response = await api.get<PaginatedResponse<Truck>>('/trucks/', { params });
    return response.data;
  },

  async getById(id: number): Promise<Truck> {
    const response = await api.get<Truck>(`/trucks/${id}/`);
    return response.data;
  },

  async create(data: Partial<Truck>): Promise<Truck> {
    const response = await api.post<Truck>('/trucks/', data);
    return response.data;
  },

  async update(id: number, data: Partial<Truck>): Promise<Truck> {
    const response = await api.put<Truck>(`/trucks/${id}/`, data);
    return response.data;
  },

  async delete(id: number): Promise<void> {
    await api.delete(`/trucks/${id}/`);
  },

  async getStats(id: number): Promise<TruckStats> {
    const response = await api.get<TruckStats>(`/trucks/${id}/stats/`);
    return response.data;
  },
};
