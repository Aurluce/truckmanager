// services/gps.service.ts
import api from './api';

export interface GPSPosition {
  id: number;
  trip: number;
  latitude: number;
  longitude: number;
  altitude: number | null;
  speed_kmh: number;
  heading: number | null;
  accuracy: number | null;
  is_stationary: boolean;
  is_abnormal_stop: boolean;
  timestamp: string;
}

export interface RealtimeTruckPosition {
  truck_id: string;
  license_plate: string;
  position: {
    lat: number;
    lng: number;
  };
  status: 'IN_TRIP' | 'IDLE' | 'OFFLINE';
  last_update: string;
  speed: number;
  trip_id?: number;
  current_weight?: number;
  fuel_level?: number;
}

export const gpsService = {
  async getCurrentPositions(): Promise<RealtimeTruckPosition[]> {
    const response = await api.get('/dashboard/fleet-map/');
    return response.data;
  },

  async getTruckPositions(truckId: string): Promise<GPSPosition[]> {
    const response = await api.get(`/gps/latest/?truck_id=${truckId}`);
    return response.data;
  },

  async getTripTrace(tripId: number): Promise<GPSPosition[]> {
    const response = await api.get(`/trips/${tripId}/positions/`);
    return response.data;
  },

  async getRealtimeData(truckId: string): Promise<any> {
    const response = await api.get(`/dashboard/realtime/${truckId}/`);
    return response.data;
  },
};