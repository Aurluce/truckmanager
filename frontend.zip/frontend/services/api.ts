import axios from 'axios';
import { ApiError } from '@/types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000/api/v1';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
  timeout: 30000,
});

api.interceptors.request.use(
  (config) => {
    if (typeof window !== 'undefined') {
      const isAuthRequest = config.url?.includes('/auth/login/') || config.url?.includes('/auth/register/') || config.url?.includes('/auth/token/refresh/');
      const token = localStorage.getItem('truckmanager_token');

      if (!isAuthRequest && token) {
        config.headers.Authorization = `Bearer ${token}`;
      } else if (config.headers.Authorization) {
        delete config.headers.Authorization;
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const apiError: ApiError = {
      message: error.response?.data?.message || 'Une erreur est survenue',
      status: error.response?.status || 500,
      errors: error.response?.data?.errors,
    };

    if (error.response?.status === 401) {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('truckmanager_token');
        localStorage.removeItem('truckmanager_user');
        window.location.href = '/login';
      }
    }

    return Promise.reject(apiError);
  }
);

export default api;
