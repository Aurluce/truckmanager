// components/map/Map.tsx
'use client';

import { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix pour les icônes Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Position {
  lat: number;
  lng: number;
  speed?: number;
  timestamp?: string;
}

interface TruckPosition {
  truck_id: string;
  license_plate: string;
  position: Position;
  status: 'IN_TRIP' | 'IDLE' | 'OFFLINE';
  last_update: string;
  speed: number;
}

interface MapProps {
  positions: TruckPosition[];
  center?: { lat: number; lng: number };
  zoom?: number;
  showTrail?: boolean;
  trailPositions?: Position[];
  onMarkerClick?: (truckId: string) => void;
}

// Composant pour centrer la carte
function MapCenter({ center }: { center: { lat: number; lng: number } }) {
  const map = useMap();
  useEffect(() => {
    map.setView([center.lat, center.lng], map.getZoom());
  }, [center, map]);
  return null;
}

export const Map = dynamic(
  () => Promise.resolve(({ 
    positions, 
    center = { lat: 4.0511, lng: 9.7679 }, 
    zoom = 12,
    showTrail = false,
    trailPositions = [],
    onMarkerClick
  }: MapProps) => {
    const [mapRef, setMapRef] = useState<any>(null);

    // Icônes personnalisées
    const createIcon = (status: string, isActive: boolean) => {
      const colors = {
        'IN_TRIP': '#10B981', // Vert
        'IDLE': '#F59E0B',    // Jaune
        'OFFLINE': '#EF4444', // Rouge
      };

      const color = isActive ? colors[status as keyof typeof colors] || '#6B7280' : '#9CA3AF';

      return L.divIcon({
        className: 'custom-marker',
        html: `
          <div style="
            width: 40px;
            height: 40px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 3px solid ${color};
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: all 0.3s;
          ">
            <div style="
              width: 16px;
              height: 16px;
              background: ${color};
              border-radius: 50%;
              animation: ${status === 'IN_TRIP' ? 'pulse 1.5s ease-in-out infinite' : 'none'};
            "></div>
          </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 40],
      });
    };

    return (
      <div className="relative w-full h-full min-h-[500px] rounded-xl overflow-hidden shadow-card">
        <MapContainer
          center={[center.lat, center.lng]}
          zoom={zoom}
          className="w-full h-full min-h-[500px]"
          ref={setMapRef}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />

          {/* Centrage */}
          <MapCenter center={center} />

          {/* Trail (trace du trajet) */}
          {showTrail && trailPositions.length > 0 && (
            <Polyline
              positions={trailPositions.map(p => [p.lat, p.lng])}
              color="#3B82F6"
              weight={3}
              opacity={0.8}
              dashArray="10, 10"
            />
          )}

          {/* Marqueurs des camions */}
          {positions.map((truck) => {
            if (!truck.position) return null;
            const isActive = truck.status !== 'OFFLINE';
            const icon = createIcon(truck.status, isActive);

            return (
              <Marker
                key={truck.truck_id}
                position={[truck.position.lat, truck.position.lng]}
                icon={icon}
                eventHandlers={{
                  click: () => onMarkerClick?.(truck.truck_id),
                }}
              >
                <Popup>
                  <div className="p-2 min-w-[200px]">
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500' : 'bg-red-500'}`} />
                      <span className="font-semibold text-gray-900">
                        {truck.license_plate}
                      </span>
                    </div>
                    <div className="space-y-1 text-sm">
                      <p className="text-gray-600">
                        ID: <span className="font-medium">{truck.truck_id}</span>
                      </p>
                      <p className="text-gray-600">
                        Statut: <span className={`font-medium ${
                          truck.status === 'IN_TRIP' ? 'text-green-600' :
                          truck.status === 'IDLE' ? 'text-yellow-600' :
                          'text-red-600'
                        }`}>
                          {truck.status === 'IN_TRIP' ? 'En trajet' :
                           truck.status === 'IDLE' ? 'À l\'arrêt' :
                           'Hors ligne'}
                        </span>
                      </p>
                      <p className="text-gray-600">
                        Vitesse: <span className="font-medium">{truck.speed || 0} km/h</span>
                      </p>
                      <p className="text-gray-600 text-xs">
                        Dernière mise à jour: {new Date(truck.last_update).toLocaleString('fr-FR')}
                      </p>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>

        {/* Légende */}
        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm rounded-xl p-3 shadow-card text-xs z-[1000]">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-gray-700">En trajet</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <span className="text-gray-700">À l'arrêt</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span className="text-gray-700">Hors ligne</span>
            </div>
          </div>
        </div>

        {/* Légende des camions */}
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-xl p-3 shadow-card text-xs z-[1000] max-h-[300px] overflow-y-auto">
          <div className="font-semibold text-gray-900 mb-2">Camions</div>
          <div className="space-y-1.5">
            {positions.map((truck) => (
              <div key={truck.truck_id} className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${
                  truck.status === 'IN_TRIP' ? 'bg-green-500' :
                  truck.status === 'IDLE' ? 'bg-yellow-500' :
                  'bg-red-500'
                }`} />
                <span className="text-gray-700 text-xs">
                  {truck.license_plate}
                </span>
              </div>
            ))}
          </div>
        </div>

        <style jsx global>{`
          @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(0.7); opacity: 0.7; }
          }
          .leaflet-container {
            border-radius: 12px;
          }
          .custom-marker {
            transition: transform 0.3s;
          }
          .custom-marker:hover {
            transform: scale(1.15);
          }
        `}</style>
      </div>
    );
  }),
  {
    ssr: false,
    loading: () => (
      <div className="w-full h-full min-h-[500px] bg-gray-100 rounded-xl flex items-center justify-center">
        <div className="text-center">
          <div className="spinner w-12 h-12 border-4 border-blue-200 border-t-blue-600 mx-auto" />
          <p className="mt-4 text-gray-500">Chargement de la carte...</p>
        </div>
      </div>
    ),
  }
);