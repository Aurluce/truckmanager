// components/ui/Badge.tsx
'use client';

import { ReactNode } from 'react';
import { twMerge } from 'tailwind-merge';

interface BadgeProps {
  children: ReactNode;
  variant?: 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'gray';
  size?: 'sm' | 'md';
  className?: string;
  dot?: boolean;
}

export const Badge = ({ 
  children, 
  variant = 'gray', 
  size = 'md',
  className = '',
  dot = false,
}: BadgeProps) => {
  const variants = {
    primary: 'bg-blue-50 text-blue-700 ring-1 ring-blue-600/20',
    success: 'bg-green-50 text-green-700 ring-1 ring-green-600/20',
    warning: 'bg-yellow-50 text-yellow-700 ring-1 ring-yellow-600/20',
    danger: 'bg-red-50 text-red-700 ring-1 ring-red-600/20',
    info: 'bg-sky-50 text-sky-700 ring-1 ring-sky-600/20',
    gray: 'bg-gray-50 text-gray-700 ring-1 ring-gray-600/20',
  };

  const sizes = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-sm',
  };

  const dotColors = {
    primary: 'bg-blue-500',
    success: 'bg-green-500',
    warning: 'bg-yellow-500',
    danger: 'bg-red-500',
    info: 'bg-sky-500',
    gray: 'bg-gray-500',
  };

  return (
    <span className={twMerge(
      'inline-flex items-center gap-1.5 rounded-full font-medium',
      variants[variant],
      sizes[size],
      className
    )}>
      {dot && (
        <span className={twMerge(
          'w-1.5 h-1.5 rounded-full',
          dotColors[variant]
        )} />
      )}
      {children}
    </span>
  );
};