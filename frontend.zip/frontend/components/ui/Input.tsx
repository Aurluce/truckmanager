// components/ui/Input.tsx
'use client';

import { forwardRef, InputHTMLAttributes } from 'react';
import { twMerge } from 'tailwind-merge';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ 
    className, 
    label, 
    error, 
    icon, 
    iconPosition = 'left',
    fullWidth = false,
    type = 'text',
    ...props 
  }, ref) => {
    const baseStyles = `
      bg-gray-50 border border-gray-200 text-gray-900 text-sm rounded-xl 
      focus:ring-2 focus:ring-blue-500 focus:border-blue-500 
      block w-full p-2.5 
      transition-all duration-200
      placeholder:text-gray-400
      ${error ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''}
      ${icon && iconPosition === 'left' ? 'pl-10' : ''}
      ${icon && iconPosition === 'right' ? 'pr-10' : ''}
      ${fullWidth ? 'w-full' : ''}
    `;

    return (
      <div className={`${fullWidth ? 'w-full' : ''}`}>
        {label && (
          <label className="block text-sm font-medium text-gray-700 mb-1.5">
            {label}
          </label>
        )}
        <div className="relative">
          {icon && iconPosition === 'left' && (
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <span className="text-gray-400">{icon}</span>
            </div>
          )}
          <input
            ref={ref}
            type={type}
            className={twMerge(baseStyles, className)}
            {...props}
          />
          {icon && iconPosition === 'right' && (
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
              <span className="text-gray-400">{icon}</span>
            </div>
          )}
        </div>
        {error && (
          <p className="mt-1.5 text-sm text-red-600 flex items-center gap-1">
            <span className="inline-block w-1 h-1 rounded-full bg-red-600"></span>
            {error}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';