// components/ui/Card.tsx
'use client';

import { ReactNode } from 'react';
import { twMerge } from 'tailwind-merge';

interface CardProps {
  children: ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
  icon?: ReactNode;
  hover?: boolean;
}

export const Card = ({ 
  children, 
  className = '', 
  title, 
  subtitle,
  icon,
  hover = false,
}: CardProps) => {
  return (
    <div className={twMerge(
      'bg-white rounded-2xl shadow-card p-6 transition-all duration-300',
      hover && 'hover:shadow-card-hover hover:-translate-y-1',
      className
    )}>
      {(title || subtitle) && (
        <div className="flex items-start justify-between mb-4">
          <div>
            {title && (
              <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
            )}
            {subtitle && (
              <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>
            )}
          </div>
          {icon && (
            <div className="p-2 bg-blue-50 rounded-xl text-blue-600">
              {icon}
            </div>
          )}
        </div>
      )}
      {children}
    </div>
  );
};