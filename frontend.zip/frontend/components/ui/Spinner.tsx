// components/ui/Spinner.tsx
'use client';

import { twMerge } from 'tailwind-merge';

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  color?: 'primary' | 'white' | 'gray';
}

export const Spinner = ({ 
  size = 'md', 
  className = '',
  color = 'primary',
}: SpinnerProps) => {
  const sizes = {
    sm: 'w-4 h-4 border-2',
    md: 'w-6 h-6 border-2',
    lg: 'w-8 h-8 border-3',
    xl: 'w-12 h-12 border-4',
  };

  const colors = {
    primary: 'border-blue-200 border-t-blue-600',
    white: 'border-white/30 border-t-white',
    gray: 'border-gray-200 border-t-gray-600',
  };

  return (
    <div className="flex justify-center items-center">
      <div className={twMerge(
        'rounded-full animate-spin',
        sizes[size],
        colors[color],
        className
      )} />
    </div>
  );
};