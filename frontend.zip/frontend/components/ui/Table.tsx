// components/ui/Table.tsx
'use client';

import { ReactNode } from 'react';
import { twMerge } from 'tailwind-merge';

interface TableProps {
  children: ReactNode;
  className?: string;
}

interface TableHeaderProps {
  children: ReactNode;
  className?: string;
}

interface TableRowProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

interface TableCellProps {
  children: ReactNode;
  className?: string;
  header?: boolean;
}

export const Table = ({ children, className = '' }: TableProps) => {
  return (
    <div className="overflow-x-auto">
      <table className={twMerge(
        'w-full text-sm text-left text-gray-500',
        className
      )}>
        {children}
      </table>
    </div>
  );
};

export const TableHeader = ({ children, className = '' }: TableHeaderProps) => {
  return (
    <thead className={twMerge(
      'text-xs text-gray-700 uppercase bg-gray-50',
      className
    )}>
      <tr>{children}</tr>
    </thead>
  );
};

export const TableBody = ({ children, className = '' }: TableHeaderProps) => {
  return (
    <tbody className={twMerge('bg-white', className)}>
      {children}
    </tbody>
  );
};

export const TableRow = ({ children, className = '', hover = true }: TableRowProps) => {
  return (
    <tr className={twMerge(
      'border-b border-gray-200',
      hover && 'hover:bg-gray-50 transition-colors',
      className
    )}>
      {children}
    </tr>
  );
};

export const TableCell = ({ children, className = '', header = false }: TableCellProps) => {
  const Component = header ? 'th' : 'td';
  return (
    <Component className={twMerge(
      'px-6 py-4',
      header ? 'font-medium text-gray-900' : '',
      className
    )}>
      {children}
    </Component>
  );
};