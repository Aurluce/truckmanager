export interface Loading {
  id: number;
  trip: number;
  truck_id: string;
  product_name: string;
  product_type: string;
  weight_kg: number;
  weight_verified: boolean;
  photo: string | null;
  is_validated: boolean;
  validated_by_name?: string;
  validated_at?: string;
  created_at: string;
  updated_at: string;
}
