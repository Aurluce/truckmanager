export interface Alert {
  id: number;
  truck: number;
  truck_id: string;
  alert_type: string;
  alert_type_display: string;
  message: string;
  threshold_value: number;
  actual_value: number;
  details?: Record<string, any>;
  status: 'PENDING' | 'RESOLVED' | 'IGNORED' | 'IN_PROGRESS';
  status_display: string;
  triggered_at: string;
  resolved_at?: string;
  resolution_notes?: string;
}
