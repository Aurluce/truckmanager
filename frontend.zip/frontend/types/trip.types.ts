export interface Trip {
  id: number;
  truck: number;
  truck_details?: Truck;
  start_time: string;
  end_time: string | null;
  start_location: string;
  end_location: string | null;
  total_distance_km: number;
  total_fuel_consumed_l: number;
  avg_fuel_consumption_l_100km: number;
  avg_fuel_per_ton_km: number;
  max_weight_kg: number;
  avg_weight_kg: number;
  status: 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  created_at: string;
  updated_at: string;
}
