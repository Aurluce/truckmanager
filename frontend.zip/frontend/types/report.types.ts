export interface Report {
  id: number;
  truck: number;
  truck_id: string;
  report_date: string;
  total_trips: number;
  total_distance_km: number;
  total_duration_hours: number;
  total_weight_kg: number;
  avg_weight_kg: number;
  total_fuel_consumed_l: number;
  avg_fuel_consumption_l_100km: number;
  avg_fuel_per_ton_km: number;
  total_revenue: number;
  total_fuel_cost: number;
  profit_margin: number;
  total_alerts: number;
  resolved_alerts: number;
  pdf_file: string | null;
  pdf_generated_at: string | null;
  created_at: string;
  updated_at: string;
}
