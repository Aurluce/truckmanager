export interface DashboardSummary {
  trucks: {
    total_trucks: number;
    active_trucks: number;
    in_trip: number;
    idle: number;
  };
  trips: {
    period_days: number;
    total_trips: number;
    completed: number;
    in_progress: number;
    total_distance_km: number;
    total_fuel_l: number;
    avg_weight_kg: number;
    avg_consumption_l_100km: number;
  };
  alerts: {
    period_days: number;
    total_alerts: number;
    pending: number;
    resolved: number;
    by_type: Array<{alert_type: string; count: number}>;
  };
  financial: {
    period_days: number;
    total_distance_km: number;
    total_fuel_l: number;
    total_weight_kg: number;
    total_cost_fcfa: number;
    total_revenue_fcfa: number;
    profit_fcfa: number;
    profit_margin: number;
  };
}
