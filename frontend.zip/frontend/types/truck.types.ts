export interface Truck {
  id: number;
  truck_id: string;
  license_plate: string;
  brand: string;
  model: string;
  year: number;
  max_capacity_kg: number;
  fuel_tank_capacity_l: number;
  owner: number;
  owner_name?: string;
  overload_threshold_kg: number;
  fuel_theft_threshold_l: number;
  abnormal_stop_minutes: number;
  cost_per_km: number;
  cost_per_liter: number;
  revenue_per_ton: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface TruckStats {
  total_trips: number;
  total_distance_km: number;
  total_fuel_l: number;
  avg_consumption: number;
}
