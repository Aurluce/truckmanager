from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.utils import timezone
from .models import Trip
from .serializers import TripSerializer, TripListSerializer
from core.permissions import IsManager

class TripViewSet(viewsets.ModelViewSet):
    """
    ViewSet pour la gestion des trajets.
    - GET /api/trips/ : Liste des trajets
    - POST /api/trips/ : Créer un trajet
    - GET /api/trips/{id}/ : Détails d'un trajet
    - PUT /api/trips/{id}/ : Modifier un trajet
    - DELETE /api/trips/{id}/ : Supprimer un trajet
    """
    
    permission_classes = [IsAuthenticated, IsManager]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'truck', 'truck__owner']
    search_fields = ['start_location', 'end_location', 'truck__truck_id']
    ordering_fields = ['start_time', 'end_time', 'total_distance_km']
    ordering = ['-start_time']
    
    def get_queryset(self):
        user = self.request.user
        queryset = Trip.objects.all()
        if not user.is_superuser:
            queryset = queryset.filter(truck__owner=user)
        return queryset
    
    def get_serializer_class(self):
        if self.action == 'list':
            return TripListSerializer
        return TripSerializer
    
    @action(detail=True, methods=['post'])
    def end_trip(self, request, pk=None):
        """Termine un trajet."""
        trip = self.get_object()
        if trip.status != 'IN_PROGRESS':
            return Response(
                {'error': 'Ce trajet est déjà terminé.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        trip.status = 'COMPLETED'
        trip.end_time = timezone.now()
        
        # Calculer les statistiques
        trip.total_distance_km = trip.calculate_distance()
        trip.save()
        
        serializer = self.get_serializer(trip)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def positions(self, request, pk=None):
        """Récupère toutes les positions GPS du trajet."""
        trip = self.get_object()
        positions = trip.gps_positions.all().order_by('timestamp')
        from measurements.serializers import GPSPositionSerializer
        serializer = GPSPositionSerializer(positions, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def trace(self, request, pk=None):
        """Récupère le tracé du trajet pour la carte."""
        trip = self.get_object()
        positions = trip.gps_positions.all().order_by('timestamp')
        data = [{
            'lat': pos.latitude,
            'lng': pos.longitude,
            'timestamp': pos.timestamp,
            'speed': pos.speed_kmh
        } for pos in positions]
        return Response(data)
