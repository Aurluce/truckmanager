# trips/models.py
from django.db import models
from django.core.validators import MinValueValidator  # 👈 Ajouter cet import
from trucks.models import Truck

class Trip(models.Model):
    """Modèle représentant un trajet."""
    
    class Status(models.TextChoices):
        IN_PROGRESS = 'IN_PROGRESS', 'En cours'
        COMPLETED = 'COMPLETED', 'Terminé'
        CANCELLED = 'CANCELLED', 'Annulé'
    
    truck = models.ForeignKey(
        Truck,
        on_delete=models.CASCADE,
        related_name='trips',
        verbose_name="Camion"
    )
    
    # Informations de base
    start_time = models.DateTimeField(verbose_name="Début du trajet")
    end_time = models.DateTimeField(null=True, blank=True, verbose_name="Fin du trajet")
    start_location = models.CharField(max_length=255, verbose_name="Lieu de départ")
    end_location = models.CharField(max_length=255, null=True, blank=True, verbose_name="Lieu d'arrivée")
    
    # Statistiques calculées
    total_distance_km = models.FloatField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Distance totale (km)"
    )
    total_fuel_consumed_l = models.FloatField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Consommation totale (L)"
    )
    avg_fuel_consumption_l_100km = models.FloatField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Consommation moyenne (L/100km)"
    )
    avg_fuel_per_ton_km = models.FloatField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Consommation par tonne (L/tonne)"
    )
    
    # Poids
    max_weight_kg = models.FloatField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Poids max (kg)"
    )
    avg_weight_kg = models.FloatField(
        default=0,
        validators=[MinValueValidator(0)],
        verbose_name="Poids moyen (kg)"
    )
    
    # Statut
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.IN_PROGRESS,
        verbose_name="Statut"
    )
    
    # Métadonnées
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Trajet"
        verbose_name_plural = "Trajets"
        ordering = ['-start_time']
        indexes = [
            models.Index(fields=['truck', 'start_time']),
            models.Index(fields=['status']),
            models.Index(fields=['truck', 'status']),
        ]
    
    def __str__(self):
        return f"Trajet {self.truck.truck_id} - {self.start_time.strftime('%Y-%m-%d %H:%M')}"