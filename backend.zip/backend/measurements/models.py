# measurements/models.py
from django.db import models
from django.core.validators import MinValueValidator  # 👈 Ajouter cet import
from trips.models import Trip

class WeightMeasurement(models.Model):
    """Mesure de poids."""
    
    trip = models.ForeignKey(
        Trip,
        on_delete=models.CASCADE,
        related_name='weight_measurements',
        verbose_name="Trajet"
    )
    
    raw_weight_kg = models.FloatField(verbose_name="Poids brut (kg)")
    filtered_weight_kg = models.FloatField(verbose_name="Poids filtré (kg)")
    calibrated_weight_kg = models.FloatField(verbose_name="Poids calibré (kg)")
    
    is_overloaded = models.BooleanField(default=False, verbose_name="Surcharge")
    
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Horodatage")
    
    class Meta:
        verbose_name = "Mesure de poids"
        verbose_name_plural = "Mesures de poids"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['trip', 'timestamp']),
        ]
    
    def __str__(self):
        return f"Poids {self.calibrated_weight_kg}kg - {self.timestamp.strftime('%H:%M')}"

class FuelMeasurement(models.Model):
    """Mesure de carburant."""
    
    trip = models.ForeignKey(
        Trip,
        on_delete=models.CASCADE,
        related_name='fuel_measurements',
        verbose_name="Trajet"
    )
    
    fuel_level_percent = models.FloatField(verbose_name="Niveau carburant (%)")
    fuel_level_liters = models.FloatField(verbose_name="Niveau carburant (L)")
    speed_kmh = models.FloatField(null=True, blank=True, verbose_name="Vitesse (km/h)")
    engine_rpm = models.IntegerField(null=True, blank=True, verbose_name="Régime moteur")
    engine_load = models.FloatField(null=True, blank=True, verbose_name="Charge moteur (%)")
    
    is_fuel_theft = models.BooleanField(default=False, verbose_name="Vol carburant détecté")
    fuel_drop_amount = models.FloatField(default=0, verbose_name="Quantité volée (L)")
    
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Horodatage")
    
    class Meta:
        verbose_name = "Mesure carburant"
        verbose_name_plural = "Mesures carburant"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['trip', 'timestamp']),
        ]
    
    def __str__(self):
        return f"Carburant {self.fuel_level_percent}% - {self.timestamp.strftime('%H:%M')}"

class GPSPosition(models.Model):
    """Position GPS."""
    
    trip = models.ForeignKey(
        Trip,
        on_delete=models.CASCADE,
        related_name='gps_positions',
        verbose_name="Trajet"
    )
    
    latitude = models.FloatField(verbose_name="Latitude")
    longitude = models.FloatField(verbose_name="Longitude")
    altitude = models.FloatField(null=True, blank=True, verbose_name="Altitude (m)")
    
    speed_kmh = models.FloatField(verbose_name="Vitesse (km/h)")
    heading = models.IntegerField(null=True, blank=True, verbose_name="Cap (°)")
    accuracy = models.FloatField(null=True, blank=True, verbose_name="Précision (m)")
    
    is_stationary = models.BooleanField(default=False, verbose_name="À l'arrêt")
    is_abnormal_stop = models.BooleanField(default=False, verbose_name="Arrêt anormal")
    
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="Horodatage")
    
    class Meta:
        verbose_name = "Position GPS"
        verbose_name_plural = "Positions GPS"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['trip', 'timestamp']),
        ]
    
    def __str__(self):
        return f"GPS {self.latitude}, {self.longitude} - {self.timestamp.strftime('%H:%M')}"