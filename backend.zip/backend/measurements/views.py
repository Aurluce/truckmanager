from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from .models import WeightMeasurement, FuelMeasurement, GPSPosition
from .serializers import (
    WeightMeasurementSerializer, FuelMeasurementSerializer, GPSPositionSerializer
)
from core.permissions import IsManager

class WeightMeasurementViewSet(viewsets.ModelViewSet):
    """ViewSet pour les mesures de poids."""
    
    permission_classes = [IsAuthenticated, IsManager]
    serializer_class = WeightMeasurementSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['trip', 'is_overloaded', 'trip__truck']
    ordering_fields = ['timestamp', 'calibrated_weight_kg']
    ordering = ['-timestamp']
    
    def get_queryset(self):
        user = self.request.user
        queryset = WeightMeasurement.objects.all()
        if not user.is_superuser:
            queryset = queryset.filter(trip__truck__owner=user)
        return queryset

class FuelMeasurementViewSet(viewsets.ModelViewSet):
    """ViewSet pour les mesures de carburant."""
    
    permission_classes = [IsAuthenticated, IsManager]
    serializer_class = FuelMeasurementSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['trip', 'is_fuel_theft', 'trip__truck']
    ordering_fields = ['timestamp', 'fuel_level_percent']
    ordering = ['-timestamp']
    
    def get_queryset(self):
        user = self.request.user
        queryset = FuelMeasurement.objects.all()
        if not user.is_superuser:
            queryset = queryset.filter(trip__truck__owner=user)
        return queryset

class GPSPositionViewSet(viewsets.ModelViewSet):
    """ViewSet pour les positions GPS."""
    
    permission_classes = [IsAuthenticated, IsManager]
    serializer_class = GPSPositionSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['trip', 'is_stationary', 'is_abnormal_stop', 'trip__truck']
    ordering_fields = ['timestamp', 'speed_kmh']
    ordering = ['-timestamp']
    
    def get_queryset(self):
        user = self.request.user
        queryset = GPSPosition.objects.all()
        if not user.is_superuser:
            queryset = queryset.filter(trip__truck__owner=user)
        return queryset
    
    @action(detail=False, methods=['get'])
    def latest(self, request):
        """Récupère la dernière position de chaque camion."""
        user = request.user
        trucks = user.trucks.all() if not user.is_superuser else Truck.objects.all()
        
        data = []
        for truck in trucks:
            trip = truck.get_current_trip()
            if trip:
                last_pos = GPSPosition.objects.filter(
                    trip=trip
                ).order_by('-timestamp').first()
                if last_pos:
                    data.append({
                        'truck_id': truck.truck_id,
                        'position': {
                            'lat': last_pos.latitude,
                            'lng': last_pos.longitude,
                        },
                        'speed': last_pos.speed_kmh,
                        'timestamp': last_pos.timestamp
                    })
        return Response(data)
