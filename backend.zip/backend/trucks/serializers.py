from rest_framework import serializers
from django.contrib.auth.models import User

from core.models import get_user_role
from .models import Truck


class TruckSerializer(serializers.ModelSerializer):
    owner_name = serializers.SerializerMethodField()
    owner = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), required=False)

    class Meta:
        model = Truck
        fields = [
            'id', 'truck_id', 'license_plate', 'brand', 'model', 'year',
            'max_capacity_kg', 'fuel_tank_capacity_l', 'owner', 'owner_name',
            'overload_threshold_kg', 'fuel_theft_threshold_l', 'abnormal_stop_minutes',
            'cost_per_km', 'cost_per_liter', 'revenue_per_ton',
            'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'truck_id']

    def validate(self, data):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return data

        owner = data.get('owner', request.user)
        role = get_user_role(request.user)

        if role != 'ADMIN' and owner != request.user:
            raise serializers.ValidationError({"owner": "Vous ne pouvez créer un camion que pour votre propre compte."})

        return data

    def create(self, validated_data):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            role = get_user_role(request.user)
            validated_data.setdefault('owner', request.user if role != 'ADMIN' else validated_data.get('owner', request.user))
        return super().create(validated_data)

    def get_owner_name(self, obj):
        return obj.owner.get_full_name() or obj.owner.username


class TruckListSerializer(serializers.ModelSerializer):
    """Serializer simplifié pour la liste des camions."""

    class Meta:
        model = Truck
        fields = ['id', 'truck_id', 'license_plate', 'brand', 'model', 'is_active']
