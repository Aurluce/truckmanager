# trucks/models.py
from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator


class Truck(models.Model):
    """Modèle représentant un camion."""

    # Identifiants
    truck_id = models.CharField(max_length=50, unique=True, db_index=True, verbose_name="ID Camion")
    license_plate = models.CharField(max_length=20, verbose_name="Plaque d'immatriculation")

    # Caractéristiques
    brand = models.CharField(max_length=100, verbose_name="Marque")
    model = models.CharField(max_length=100, verbose_name="Modèle")
    year = models.IntegerField(verbose_name="Année")
    max_capacity_kg = models.FloatField(
        validators=[MinValueValidator(0)],
        verbose_name="Capacité max (kg)"
    )
    fuel_tank_capacity_l = models.FloatField(
        validators=[MinValueValidator(0)],
        verbose_name="Capacité réservoir (L)"
    )

    # Propriétaire
    owner = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='trucks',
        verbose_name="Propriétaire"
    )

    # Paramètres d'alerte
    overload_threshold_kg = models.FloatField(
        default=3000,
        validators=[MinValueValidator(0)],
        verbose_name="Seuil surcharge (kg)"
    )
    fuel_theft_threshold_l = models.FloatField(
        default=2.0,
        validators=[MinValueValidator(0)],
        verbose_name="Seuil vol carburant (L)"
    )
    abnormal_stop_minutes = models.IntegerField(
        default=30,
        validators=[MinValueValidator(1)],
        verbose_name="Arrêt anormal (min)"
    )

    # Prix de revient
    cost_per_km = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        verbose_name="Coût au km"
    )
    cost_per_liter = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        verbose_name="Coût au litre"
    )
    revenue_per_ton = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        verbose_name="Recette par tonne"
    )

    # Métadonnées
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True, verbose_name="Actif")

    class Meta:
        verbose_name = "Camion"
        verbose_name_plural = "Camions"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['truck_id']),
            models.Index(fields=['owner', 'is_active']),
        ]

    def generate_unique_truck_id(self):
        """Génère un identifiant unique pour le camion sous le format TRK-000001."""
        last_truck = Truck.objects.filter(truck_id__startswith='TRK-').order_by('-truck_id').first()
        last_number = 0

        if last_truck and last_truck.truck_id:
            try:
                last_number = int(last_truck.truck_id.replace('TRK-', ''))
            except ValueError:
                last_number = 0

        next_number = last_number + 1
        while True:
            candidate = f'TRK-{next_number:06d}'
            if not Truck.objects.filter(truck_id=candidate).exists():
                self.truck_id = candidate
                return
            next_number += 1

    def save(self, *args, **kwargs):
        if not self.truck_id or not self.truck_id.strip():
            self.generate_unique_truck_id()
        else:
            self.truck_id = self.truck_id.strip().upper()

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.truck_id} - {self.license_plate}"

    def get_current_trip(self):
        """Récupère le trajet en cours."""
        return self.trips.filter(status='IN_PROGRESS').first()