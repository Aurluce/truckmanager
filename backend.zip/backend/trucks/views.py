from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from core.models import get_user_role
from .models import Truck
from .serializers import TruckSerializer, TruckListSerializer
from core.permissions import IsAdmin, IsManager, IsOwnerOrReadOnly


class TruckViewSet(viewsets.ModelViewSet):
    """
    ViewSet pour la gestion des camions.
    - GET /api/trucks/ : Liste des camions
    - POST /api/trucks/ : Créer un camion
    - GET /api/trucks/{id}/ : Détails d'un camion
    - PUT /api/trucks/{id}/ : Modifier un camion
    - DELETE /api/trucks/{id}/ : Supprimer un camion
    """

    permission_classes = [IsAuthenticated, IsOwnerOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['is_active', 'brand', 'year', 'owner']
    search_fields = ['truck_id', 'license_plate', 'brand', 'model']
    ordering_fields = ['created_at', 'brand', 'year']
    ordering = ['-created_at']

    def get_queryset(self):
        user = self.request.user
        if user.is_superuser or get_user_role(user) == 'ADMIN':
            return Truck.objects.all()
        return Truck.objects.filter(owner=user)

    def get_serializer_class(self):
        if self.action == 'list':
            return TruckListSerializer
        return TruckSerializer

    def perform_create(self, serializer):
        user = self.request.user
        if user.is_superuser or get_user_role(user) == 'ADMIN':
            owner = serializer.validated_data.get('owner', user)
        else:
            owner = user
        serializer.save(owner=owner)
    
    @action(detail=True, methods=['get'])
    def current_trip(self, request, pk=None):
        """Récupère le trajet en cours du camion."""
        truck = self.get_object()
        trip = truck.get_current_trip()
        if trip:
            from trips.serializers import TripSerializer
            serializer = TripSerializer(trip)
            return Response(serializer.data)
        return Response({'message': 'Aucun trajet en cours'}, status=status.HTTP_404_NOT_FOUND)
    
    @action(detail=True, methods=['get'])
    def stats(self, request, pk=None):
        """Statistiques du camion."""
        truck = self.get_object()
        from dashboard.services import DashboardService
        data = {
            'truck': TruckSerializer(truck).data,
            'trips': DashboardService.get_trips_stats(truck.id),
            'alerts': DashboardService.get_alerts_summary(truck.id),
            'financial': DashboardService.get_financial_stats(truck.id),
        }
        return Response(data)
