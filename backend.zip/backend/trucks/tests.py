from django.contrib.auth.models import User
from django.test import TestCase

from trucks.models import Truck


class TruckIdentifierTests(TestCase):
    def test_truck_id_is_generated_if_missing(self):
        owner = User.objects.create_user(
            username='owner2',
            email='owner2@test.com',
            password='pass1234',
        )

        truck = Truck.objects.create(
            truck_id='',
            license_plate='AB-123-CD',
            brand='Volvo',
            model='FH',
            year=2024,
            max_capacity_kg=15000,
            fuel_tank_capacity_l=400,
            owner=owner,
        )

        self.assertRegex(truck.truck_id, r'^TRK-\d{6}$')

    def test_truck_id_is_unique(self):
        owner = User.objects.create_user(
            username='owner3',
            email='owner3@test.com',
            password='pass1234',
        )

        truck_a = Truck.objects.create(
            truck_id='TRK-000001',
            license_plate='AB-123-CD',
            brand='Volvo',
            model='FH',
            year=2024,
            max_capacity_kg=15000,
            fuel_tank_capacity_l=400,
            owner=owner,
        )
        truck_b = Truck.objects.create(
            truck_id='TRK-000002',
            license_plate='EF-456-GH',
            brand='Mercedes',
            model='Actros',
            year=2023,
            max_capacity_kg=16000,
            fuel_tank_capacity_l=450,
            owner=owner,
        )

        self.assertNotEqual(truck_a.truck_id, truck_b.truck_id)
        self.assertTrue(truck_a.truck_id.startswith('TRK-'))
        self.assertTrue(truck_b.truck_id.startswith('TRK-'))
