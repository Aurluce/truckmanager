from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

# Swagger documentation
schema_view = get_schema_view(
    openapi.Info(
        title="TruckManager API",
        default_version='v1',
        description="API pour la gestion de flotte TruckManager",
        terms_of_service="https://www.truckmanager.com/terms/",
        contact=openapi.Contact(email="support@truckmanager.com"),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

# API Version
API_VERSION = 'v1'

urlpatterns = [
    # Admin
    path('admin/', admin.site.urls),
    
    # API Documentation
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path('swagger.json', schema_view.without_ui(cache_timeout=0), name='schema-json'),
    
    # API Routes
    path(f'api/{API_VERSION}/auth/', include('core.urls')),
    path(f'api/{API_VERSION}/', include('trucks.urls')),
    path(f'api/{API_VERSION}/', include('trips.urls')),
    path(f'api/{API_VERSION}/', include('measurements.urls')),
    path(f'api/{API_VERSION}/', include('alerts.urls')),
    path(f'api/{API_VERSION}/', include('loadings.urls')),
    path(f'api/{API_VERSION}/', include('reports.urls')),
    path(f'api/{API_VERSION}/dashboard/', include('dashboard.urls')),
]

# Serve media and static files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
