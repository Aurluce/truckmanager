from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.http import HttpResponse
from django.utils import timezone
from .models import Report
from .serializers import ReportSerializer, ReportListSerializer
from core.permissions import IsManager
from dashboard.utils import generate_pdf_report

class ReportViewSet(viewsets.ModelViewSet):
    """
    ViewSet pour la gestion des rapports.
    - GET /api/reports/ : Liste des rapports
    - POST /api/reports/ : Créer un rapport
    - GET /api/reports/{id}/ : Détails d'un rapport
    - PUT /api/reports/{id}/ : Modifier un rapport
    - DELETE /api/reports/{id}/ : Supprimer un rapport
    """
    
    permission_classes = [IsAuthenticated, IsManager]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['truck', 'report_date', 'truck__owner']
    search_fields = ['truck__truck_id']
    ordering_fields = ['report_date', 'created_at']
    ordering = ['-report_date']
    
    def get_queryset(self):
        user = self.request.user
        queryset = Report.objects.all()
        if not user.is_superuser:
            queryset = queryset.filter(truck__owner=user)
        return queryset
    
    def get_serializer_class(self):
        if self.action == 'list':
            return ReportListSerializer
        return ReportSerializer
    
    @action(detail=True, methods=['get'])
    def download_pdf(self, request, pk=None):
        """Télécharge le rapport en PDF."""
        report = self.get_object()
        
        if not report.pdf_file:
            # Générer le PDF si non existant
            pdf_buffer = generate_pdf_report(report.truck.id, 'month')
            response = HttpResponse(pdf_buffer, content_type='application/pdf')
            response['Content-Disposition'] = f'attachment; filename="rapport_{report.truck.truck_id}_{report.report_date}.pdf"'
            return response
        
        # Retourner le PDF existant
        response = HttpResponse(report.pdf_file.read(), content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="{report.pdf_file.name}"'
        return response
    
    @action(detail=False, methods=['post'])
    def generate(self, request):
        """Génère un rapport pour une date spécifique."""
        truck_id = request.data.get('truck_id')
        report_date = request.data.get('report_date', timezone.now().date())
        
        from dashboard.services import DashboardService
        # Logique de génération de rapport
        # À implémenter selon vos besoins
        
        return Response({'message': 'Rapport généré avec succès'})
