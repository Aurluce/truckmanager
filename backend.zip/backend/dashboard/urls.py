from django.urls import path
from .views import (
    DashboardSummaryView,
    RealtimeDataView,
    FleetMapView,
    TripsChartView,
    AlertsListView,
    CurrentLoadsView,
    PerformanceReportView,
)

urlpatterns = [
    path('summary/', DashboardSummaryView.as_view(), name='dashboard_summary'),
    path('realtime/<int:truck_id>/', RealtimeDataView.as_view(), name='realtime_data'),
    path('fleet-map/', FleetMapView.as_view(), name='fleet_map'),
    path('chart/trips/', TripsChartView.as_view(), name='trips_chart'),
    path('alerts/', AlertsListView.as_view(), name='alerts_list'),
    path('current-loads/', CurrentLoadsView.as_view(), name='current_loads'),
    path('performance-report/', PerformanceReportView.as_view(), name='performance_report'),
]
