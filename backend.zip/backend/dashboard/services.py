# dashboard/services.py
from django.db.models import Sum, Avg, Count, Q
from django.utils import timezone
from datetime import datetime, timedelta
from trucks.models import Truck
from trips.models import Trip
from measurements.models import WeightMeasurement, FuelMeasurement, GPSPosition
from alerts.models import Alert
from loadings.models import Loading
from reports.models import Report

class DashboardService:
    """Service pour les données du dashboard."""
    
    @staticmethod
    def get_truck_stats(truck_id=None):
        """Statistiques générales des camions."""
        queryset = Truck.objects.filter(is_active=True)
        if truck_id:
            queryset = queryset.filter(id=truck_id)
        
        total_trucks = queryset.count()
        active_trucks = queryset.filter(is_active=True).count()
        
        # Camions en trajet
        in_trip = queryset.filter(trips__status='IN_PROGRESS').distinct().count()
        
        return {
            'total_trucks': total_trucks,
            'active_trucks': active_trucks,
            'in_trip': in_trip,
            'idle': total_trucks - in_trip,
        }
    
    @staticmethod
    def get_trips_stats(truck_id=None, days=7):
        """Statistiques des trajets."""
        queryset = Trip.objects.all()
        if truck_id:
            queryset = queryset.filter(truck_id=truck_id)
        
        # Période
        start_date = timezone.now() - timedelta(days=days)
        period_queryset = queryset.filter(start_time__gte=start_date)
        
        # Statistiques
        total_trips = period_queryset.count()
        completed = period_queryset.filter(status='COMPLETED').count()
        in_progress = period_queryset.filter(status='IN_PROGRESS').count()
        
        # Kilométrage
        total_distance = period_queryset.aggregate(
            total=Sum('total_distance_km')
        )['total'] or 0
        
        # Consommation
        total_fuel = period_queryset.aggregate(
            total=Sum('total_fuel_consumed_l')
        )['total'] or 0
        
        # Poids
        avg_weight = period_queryset.aggregate(
            avg=Avg('avg_weight_kg')
        )['avg'] or 0
        
        return {
            'period_days': days,
            'total_trips': total_trips,
            'completed': completed,
            'in_progress': in_progress,
            'total_distance_km': round(total_distance, 2),
            'total_fuel_l': round(total_fuel, 2),
            'avg_weight_kg': round(avg_weight, 2),
            'avg_consumption_l_100km': round(total_fuel / total_distance * 100, 2) if total_distance > 0 else 0,
        }
    
    @staticmethod
    def get_realtime_data(truck_id):
        """Données en temps réel pour un camion."""
        try:
            truck = Truck.objects.get(id=truck_id)
            current_trip = truck.get_current_trip()
            
            if not current_trip:
                return {
                    'truck_id': truck.truck_id,
                    'status': 'IDLE',
                    'message': 'Camion à l\'arrêt'
                }
            
            # Dernières mesures
            last_weight = WeightMeasurement.objects.filter(
                trip=current_trip
            ).order_by('-timestamp').first()
            
            last_fuel = FuelMeasurement.objects.filter(
                trip=current_trip
            ).order_by('-timestamp').first()
            
            last_gps = GPSPosition.objects.filter(
                trip=current_trip
            ).order_by('-timestamp').first()
            
            return {
                'truck_id': truck.truck_id,
                'status': 'IN_TRIP',
                'trip_id': current_trip.id,
                'start_time': current_trip.start_time,
                'duration': (timezone.now() - current_trip.start_time).total_seconds() / 3600,
                'current_weight': last_weight.calibrated_weight_kg if last_weight else 0,
                'fuel_level': last_fuel.fuel_level_percent if last_fuel else 0,
                'fuel_liters': last_fuel.fuel_level_liters if last_fuel else 0,
                'speed': last_gps.speed_kmh if last_gps else 0,
                'position': {
                    'lat': last_gps.latitude if last_gps else None,
                    'lng': last_gps.longitude if last_gps else None,
                },
                'is_overloaded': last_weight.is_overloaded if last_weight else False,
            }
        except Truck.DoesNotExist:
            return None
    
    @staticmethod
    def get_alerts_summary(truck_id=None, days=7):
        """Résumé des alertes."""
        queryset = Alert.objects.all()
        if truck_id:
            queryset = queryset.filter(truck_id=truck_id)
        
        start_date = timezone.now() - timedelta(days=days)
        period_queryset = queryset.filter(triggered_at__gte=start_date)
        
        total_alerts = period_queryset.count()
        pending = period_queryset.filter(status='PENDING').count()
        resolved = period_queryset.filter(status='RESOLVED').count()
        
        # Par type
        alerts_by_type = period_queryset.values('alert_type').annotate(
            count=Count('id')
        ).order_by('-count')
        
        return {
            'period_days': days,
            'total_alerts': total_alerts,
            'pending': pending,
            'resolved': resolved,
            'by_type': list(alerts_by_type),
        }
    
    @staticmethod
    def get_financial_stats(truck_id=None, days=30):
        """Statistiques financières."""
        queryset = Trip.objects.filter(status='COMPLETED')
        if truck_id:
            queryset = queryset.filter(truck_id=truck_id)
        
        start_date = timezone.now() - timedelta(days=days)
        period_queryset = queryset.filter(end_time__gte=start_date)
        
        # Calculs
        total_distance = period_queryset.aggregate(
            total=Sum('total_distance_km')
        )['total'] or 0
        
        total_fuel = period_queryset.aggregate(
            total=Sum('total_fuel_consumed_l')
        )['total'] or 0
        
        total_weight = period_queryset.aggregate(
            total=Sum('avg_weight_kg')
        )['total'] or 0
        
        # Récupérer les coûts du camion
        truck = Truck.objects.get(id=truck_id) if truck_id else None
        cost_per_km = truck.cost_per_km if truck else 0
        cost_per_liter = truck.cost_per_liter if truck else 0
        revenue_per_ton = truck.revenue_per_ton if truck else 0
        
        total_cost = (total_distance * cost_per_km) + (total_fuel * cost_per_liter)
        total_revenue = (total_weight / 1000) * revenue_per_ton  # tonne
        profit = total_revenue - total_cost
        
        return {
            'period_days': days,
            'total_distance_km': round(total_distance, 2),
            'total_fuel_l': round(total_fuel, 2),
            'total_weight_kg': round(total_weight, 2),
            'total_cost_fcfa': round(total_cost, 0),
            'total_revenue_fcfa': round(total_revenue, 0),
            'profit_fcfa': round(profit, 0),
            'profit_margin': round((profit / total_revenue * 100), 2) if total_revenue > 0 else 0,
        }
    
    @staticmethod
    def get_trips_chart_data(truck_id=None, days=30):
        """Données pour le graphique des trajets."""
        queryset = Trip.objects.filter(status='COMPLETED')
        if truck_id:
            queryset = queryset.filter(truck_id=truck_id)
        
        start_date = timezone.now() - timedelta(days=days)
        period_queryset = queryset.filter(end_time__gte=start_date)
        
        # Grouper par jour
        chart_data = []
        current = start_date
        while current <= timezone.now():
            day_start = current.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            
            day_trips = period_queryset.filter(
                end_time__gte=day_start,
                end_time__lte=day_end
            )
            
            chart_data.append({
                'date': day_start.strftime('%Y-%m-%d'),
                'trips': day_trips.count(),
                'distance': day_trips.aggregate(total=Sum('total_distance_km'))['total'] or 0,
                'fuel': day_trips.aggregate(total=Sum('total_fuel_consumed_l'))['total'] or 0,
            })
            
            current = day_end
        
        return chart_data
    
    @staticmethod
    def get_fleet_map_data(truck_id=None):
        """Données pour la carte de la flotte."""
        trucks = Truck.objects.filter(is_active=True)
        if truck_id:
            trucks = trucks.filter(id=truck_id)
        
        fleet_data = []
        for truck in trucks:
            current_trip = truck.get_current_trip()
            if current_trip:
                last_gps = GPSPosition.objects.filter(
                    trip=current_trip
                ).order_by('-timestamp').first()
                
                if last_gps:
                    fleet_data.append({
                        'truck_id': truck.truck_id,
                        'license_plate': truck.license_plate,
                        'position': {
                            'lat': last_gps.latitude,
                            'lng': last_gps.longitude,
                        },
                        'speed': last_gps.speed_kmh,
                        'status': 'IN_TRIP',
                        'last_update': last_gps.timestamp,
                    })
                    continue
            
            fleet_data.append({
                'truck_id': truck.truck_id,
                'license_plate': truck.license_plate,
                'position': None,
                'status': 'IDLE',
                'last_update': None,
            })
        
        return fleet_data