from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from .services import DashboardService
from .serializers import (
    DashboardSummarySerializer, RealtimeDataSerializer,
    TruckStatusSerializer, ChartDataSerializer
)
from trucks.models import Truck
from alerts.models import Alert
from loadings.models import Loading
from core.permissions import IsManager

class DashboardSummaryView(APIView):
    """Vue pour le résumé du dashboard."""
    
    permission_classes = [IsAuthenticated, IsManager]
    
    def get(self, request):
        truck_id = request.query_params.get('truck_id')
        days = int(request.query_params.get('days', 30))
        
        data = {
            'trucks': DashboardService.get_truck_stats(truck_id),
            'trips': DashboardService.get_trips_stats(truck_id, min(days, 30)),
            'alerts': DashboardService.get_alerts_summary(truck_id, min(days, 7)),
            'financial': DashboardService.get_financial_stats(truck_id, min(days, 30)),
        }
        
        serializer = DashboardSummarySerializer(data)
        return Response(serializer.data)


class RealtimeDataView(APIView):
    """Vue pour les données en temps réel d'un camion."""
    
    permission_classes = [IsAuthenticated]
    
    def get(self, request, truck_id):
        truck = get_object_or_404(Truck, id=truck_id)
        
        if not request.user.is_superuser and truck.owner != request.user:
            return Response(
                {'error': 'Vous n\'avez pas accès à ce camion.'},
                status=status.HTTP_403_FORBIDDEN
            )
        
        data = DashboardService.get_realtime_data(truck_id)
        
        if not data:
            return Response(
                {'message': 'Camion inactif ou en attente.'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        serializer = RealtimeDataSerializer(data)
        return Response(serializer.data)


class FleetMapView(APIView):
    """Vue pour la carte de la flotte."""
    
    permission_classes = [IsAuthenticated, IsManager]
    
    def get(self, request):
        truck_id = request.query_params.get('truck_id')
        data = DashboardService.get_fleet_map_data(truck_id)
        serializer = TruckStatusSerializer(data, many=True)
        return Response(serializer.data)


class TripsChartView(APIView):
    """Vue pour les données des graphiques de trajets."""
    
    permission_classes = [IsAuthenticated, IsManager]
    
    def get(self, request):
        truck_id = request.query_params.get('truck_id')
        days = int(request.query_params.get('days', 30))
        
        data = DashboardService.get_trips_chart_data(truck_id, min(days, 90))
        serializer = ChartDataSerializer(data, many=True)
        return Response(serializer.data)


class AlertsListView(APIView):
    """Vue pour la liste des alertes récentes."""
    
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        truck_id = request.query_params.get('truck_id')
        limit = int(request.query_params.get('limit', 20))
        
        queryset = Alert.objects.all().order_by('-triggered_at')
        
        if truck_id:
            queryset = queryset.filter(truck_id=truck_id)
        
        if not request.user.is_superuser:
            queryset = queryset.filter(truck__owner=request.user)
        
        alerts = queryset[:limit]
        
        data = [{
            'id': alert.id,
            'type': alert.get_alert_type_display(),
            'message': alert.message,
            'truck': alert.truck.truck_id,
            'status': alert.get_status_display(),
            'triggered_at': alert.triggered_at,
        } for alert in alerts]
        
        return Response(data)


class CurrentLoadsView(APIView):
    """Vue pour les chargements en cours."""
    
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        truck_id = request.query_params.get('truck_id')
        
        queryset = Loading.objects.filter(
            trip__status='IN_PROGRESS'
        ).order_by('-created_at')
        
        if truck_id:
            queryset = queryset.filter(trip__truck_id=truck_id)
        
        if not request.user.is_superuser:
            queryset = queryset.filter(trip__truck__owner=request.user)
        
        data = [{
            'id': loading.id,
            'product_name': loading.product_name,
            'weight_kg': loading.weight_kg,
            'truck': loading.trip.truck.truck_id,
            'photo': loading.photo.url if loading.photo else None,
            'is_validated': loading.is_validated,
            'created_at': loading.created_at,
        } for loading in queryset[:10]]
        
        return Response(data)


class PerformanceReportView(APIView):
    """Vue pour générer un rapport de performance."""
    
    permission_classes = [IsAuthenticated, IsManager]
    
    def get(self, request):
        truck_id = request.query_params.get('truck_id')
        period = request.query_params.get('period', 'month')
        
        from dashboard.utils import generate_pdf_report
        pdf_buffer = generate_pdf_report(truck_id, period)
        
        response = HttpResponse(pdf_buffer, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="performance_report.pdf"'
        return response
