from rest_framework import serializers
from .models import Loading

class LoadingSerializer(serializers.ModelSerializer):
    truck_id = serializers.CharField(source='trip.truck.truck_id', read_only=True)
    validated_by_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Loading
        fields = [
            'id', 'trip', 'truck_id',
            'product_name', 'product_type',
            'weight_kg', 'weight_verified',
            'photo', 'photo_taken_at',
            'is_validated', 'validated_by', 'validated_by_name',
            'validated_at', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    def get_validated_by_name(self, obj):
        if obj.validated_by:
            return obj.validated_by.get_full_name() or obj.validated_by.username
        return None

class LoadingListSerializer(serializers.ModelSerializer):
    """Serializer simplifié pour la liste des chargements."""
    
    truck_id = serializers.CharField(source='trip.truck.truck_id', read_only=True)
    
    class Meta:
        model = Loading
        fields = [
            'id', 'truck_id', 'product_name', 'weight_kg',
            'is_validated', 'created_at'
        ]
